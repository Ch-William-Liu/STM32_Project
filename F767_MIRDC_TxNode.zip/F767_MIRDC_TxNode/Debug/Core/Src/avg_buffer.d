Core/Src/avg_buffer.o: ../Core/Src/avg_buffer.c ../Core/Inc/avg_buffer.h \
 ../Core/Inc/imu_types.h
../Core/Inc/avg_buffer.h:
../Core/Inc/imu_types.h:
