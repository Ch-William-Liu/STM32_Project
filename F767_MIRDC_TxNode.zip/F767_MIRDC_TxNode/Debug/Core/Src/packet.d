Core/Src/packet.o: ../Core/Src/packet.c ../Core/Inc/packet.h \
 ../Core/Inc/imu_types.h ../Core/Inc/crc16.h
../Core/Inc/packet.h:
../Core/Inc/imu_types.h:
../Core/Inc/crc16.h:
