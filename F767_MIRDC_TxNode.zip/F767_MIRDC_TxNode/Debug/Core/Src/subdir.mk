################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (13.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Core/Src/avg_buffer.c \
../Core/Src/crc16.c \
../Core/Src/dac_stream.c \
../Core/Src/dbpsk.c \
../Core/Src/ds3231.c \
../Core/Src/fatfs_sd.c \
../Core/Src/led_ctrl.c \
../Core/Src/main.c \
../Core/Src/mpu6050.c \
../Core/Src/packet.c \
../Core/Src/relay_ctrl.c \
../Core/Src/sd_logger.c \
../Core/Src/stm32f7xx_hal_msp.c \
../Core/Src/stm32f7xx_it.c \
../Core/Src/syscalls.c \
../Core/Src/sysmem.c \
../Core/Src/system_stm32f7xx.c 

OBJS += \
./Core/Src/avg_buffer.o \
./Core/Src/crc16.o \
./Core/Src/dac_stream.o \
./Core/Src/dbpsk.o \
./Core/Src/ds3231.o \
./Core/Src/fatfs_sd.o \
./Core/Src/led_ctrl.o \
./Core/Src/main.o \
./Core/Src/mpu6050.o \
./Core/Src/packet.o \
./Core/Src/relay_ctrl.o \
./Core/Src/sd_logger.o \
./Core/Src/stm32f7xx_hal_msp.o \
./Core/Src/stm32f7xx_it.o \
./Core/Src/syscalls.o \
./Core/Src/sysmem.o \
./Core/Src/system_stm32f7xx.o 

C_DEPS += \
./Core/Src/avg_buffer.d \
./Core/Src/crc16.d \
./Core/Src/dac_stream.d \
./Core/Src/dbpsk.d \
./Core/Src/ds3231.d \
./Core/Src/fatfs_sd.d \
./Core/Src/led_ctrl.d \
./Core/Src/main.d \
./Core/Src/mpu6050.d \
./Core/Src/packet.d \
./Core/Src/relay_ctrl.d \
./Core/Src/sd_logger.d \
./Core/Src/stm32f7xx_hal_msp.d \
./Core/Src/stm32f7xx_it.d \
./Core/Src/syscalls.d \
./Core/Src/sysmem.d \
./Core/Src/system_stm32f7xx.d 


# Each subdirectory must supply rules for building sources it contributes
Core/Src/%.o Core/Src/%.su Core/Src/%.cyclo: ../Core/Src/%.c Core/Src/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m7 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F767xx -c -I../FATFS/Target -I../FATFS/App -I../Core/Inc -I../Drivers/STM32F7xx_HAL_Driver/Inc -I../Drivers/STM32F7xx_HAL_Driver/Inc/Legacy -I../Middlewares/Third_Party/FatFs/src -I../Drivers/CMSIS/Device/ST/STM32F7xx/Include -I../Drivers/CMSIS/Include -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv5-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-Core-2f-Src

clean-Core-2f-Src:
	-$(RM) ./Core/Src/avg_buffer.cyclo ./Core/Src/avg_buffer.d ./Core/Src/avg_buffer.o ./Core/Src/avg_buffer.su ./Core/Src/crc16.cyclo ./Core/Src/crc16.d ./Core/Src/crc16.o ./Core/Src/crc16.su ./Core/Src/dac_stream.cyclo ./Core/Src/dac_stream.d ./Core/Src/dac_stream.o ./Core/Src/dac_stream.su ./Core/Src/dbpsk.cyclo ./Core/Src/dbpsk.d ./Core/Src/dbpsk.o ./Core/Src/dbpsk.su ./Core/Src/ds3231.cyclo ./Core/Src/ds3231.d ./Core/Src/ds3231.o ./Core/Src/ds3231.su ./Core/Src/fatfs_sd.cyclo ./Core/Src/fatfs_sd.d ./Core/Src/fatfs_sd.o ./Core/Src/fatfs_sd.su ./Core/Src/led_ctrl.cyclo ./Core/Src/led_ctrl.d ./Core/Src/led_ctrl.o ./Core/Src/led_ctrl.su ./Core/Src/main.cyclo ./Core/Src/main.d ./Core/Src/main.o ./Core/Src/main.su ./Core/Src/mpu6050.cyclo ./Core/Src/mpu6050.d ./Core/Src/mpu6050.o ./Core/Src/mpu6050.su ./Core/Src/packet.cyclo ./Core/Src/packet.d ./Core/Src/packet.o ./Core/Src/packet.su ./Core/Src/relay_ctrl.cyclo ./Core/Src/relay_ctrl.d ./Core/Src/relay_ctrl.o ./Core/Src/relay_ctrl.su ./Core/Src/sd_logger.cyclo ./Core/Src/sd_logger.d ./Core/Src/sd_logger.o ./Core/Src/sd_logger.su ./Core/Src/stm32f7xx_hal_msp.cyclo ./Core/Src/stm32f7xx_hal_msp.d ./Core/Src/stm32f7xx_hal_msp.o ./Core/Src/stm32f7xx_hal_msp.su ./Core/Src/stm32f7xx_it.cyclo ./Core/Src/stm32f7xx_it.d ./Core/Src/stm32f7xx_it.o ./Core/Src/stm32f7xx_it.su ./Core/Src/syscalls.cyclo ./Core/Src/syscalls.d ./Core/Src/syscalls.o ./Core/Src/syscalls.su ./Core/Src/sysmem.cyclo ./Core/Src/sysmem.d ./Core/Src/sysmem.o ./Core/Src/sysmem.su ./Core/Src/system_stm32f7xx.cyclo ./Core/Src/system_stm32f7xx.d ./Core/Src/system_stm32f7xx.o ./Core/Src/system_stm32f7xx.su

.PHONY: clean-Core-2f-Src

